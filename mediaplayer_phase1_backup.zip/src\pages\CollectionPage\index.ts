export { CollectionPage } from './CollectionPage';
